#loading the dataset
train = read.csv("train.csv")
test = read.csv("test.csv")
str(train)
str(test)
#lets look at rows of train and test dataset
head(train)
head(test)
#convert target to factor
train$target = as.factor(train$target)
#Count of target class
table(train$target)
#count of target class in percentage
table(train$target)/length(train$target)*100
#Bar plot graph for count of target class
library(ggplot2)
ggplot(train,aes(target))+theme_bw()+geom_bar(stat='count',fill='red')
#missing value 
sum(is.na(train))
sum(is.na(test))

#Split the data using CreateDataPartition
set.seed(450)
#train.ind<-createDataPartition(train_df$target,p=0.8,list=FALSE)
train.ind<-sample(1:nrow(train),0.8*nrow(train))
#train data
train.data<-train[train.ind,]
#validation data
valid.data<-train[-train.ind,]
#dimension of train data
dim(train.data)
#dimension of validation data
dim(valid.data) 
#target classes in train data
table(train.data$target)
#target classes in validation data
table(valid.data$target)

#Logistic Regression model
#Training dataset
X_T<-as.matrix(train.data[,-c(1,2)])
y_T<-as.matrix(train.data$target)
#validation dataset
X_V<-as.matrix(valid.data[,-c(1,2)])
y_V<-as.matrix(valid.data$target)
#test dataset
tests<-as.matrix(test[,-c(1)])

#Logistic regression model
set.seed(448) 
library(glmnet)
logr_model <-glmnet(X_T,y_T, family = "binomial")
summary(logr_model)


#Cross validation prediction
set.seed(7500)
cv_logr <- cv.glmnet(X_T,y_T,family = "binomial", type.measure = "class")
cv_logr


#Plotting the missclassification error vs log(lambda) where lambda is regularization parameter
#Minimum lambda
cv_logr$lambda.min
#plot the auc score vs log(lambda)
plot(cv_logr)
#We can observed that miss classification error increases as increasing the log(Lambda)

#Model performance on validation dataset
set.seed(4223)
cv_predict.logr<-predict(cv_logr,X_V,s = "lambda.min", type = "class")
cv_predict.logr

#Confusion matrix
set.seed(450)
#actual target variable
target<-valid.data$target
#convert to factor
target<-as.factor(target)
#predicted target variable
#convert to factor
cv_predict.logr<-as.factor(cv_predict.logr)
library(caret)
install.packages('e1071', dependencies=TRUE)
confusionMatrix(data=cv_predict.logr,reference=target)

#Random Oversampling Examples(ROSE)

library(ROSE)
library(yardstick)
set.seed(655)
train.rose <- ROSE(target~., data =train.data[,-c(1)],seed=30)$data
#target classes in balanced train data
table(train.rose$target)
valid.rose <- ROSE(target~., data =valid.data[,-c(1)],seed=40)$data
#target classes in balanced valid data
table(valid.rose$target)


#Let us see how baseline logistic regression model performs on synthetic data points

set.seed(362)
logr_rose <-glmnet(as.matrix(train.rose),as.matrix(train.rose$target), family = "binomial")
summary(logr_rose)
#Cross validation prediction
set.seed(352)
cv_rose = cv.glmnet(as.matrix(valid.rose),as.matrix(valid.rose$target),family = "binomial", type.measure = "class")
cv_rose

#Plotting the missclassification error vs log(lambda) where lambda is regularization parameter
#Minimum lambda
cv_rose$lambda.min

#plot the auc score vs log(lambda)
plot(cv_rose)

#Model performance on validation dataset
set.seed(352)
cv_predict.rose<-predict(cv_rose,as.matrix(valid.rose),s = "lambda.min", type = "class")
cv_predict.rose

#Confusion matrix
set.seed(378)
#actual target variable
target<-valid.rose$target
#convert to factor
target<-as.factor(target)
#predicted target variable
#convert to factor
cv_predict.rose<-as.factor(cv_predict.rose)
#Confusion matrix
confusionMatrix(data=cv_predict.rose,reference=target)

#XGboost model

library(tidyverse)
library(caret)
library(plyr)
library(xgboost)

train_data_n <- train
train_data_n$ID_code <- NULL
dtrain <- xgb.DMatrix(as.matrix(train_data_n %>% select(-target)), label = train_data_n$target)
start.time <- Sys.time()
bst <- xgboost(data = dtrain, max_depth = 10, eta = 1, nrounds = 30, objective = "binary:logistic")
end.time <- Sys.time()
test$ID_code <- NULL
test = xgb.DMatrix(as.matrix(test))
pred <- predict(bst, test)
submission <- read.csv("/home/akshay/Downloads/submission_xgb.csv")
submission$target <- pred
write.csv(submission, file="sub_xgb.csv", row.names=F)

#we are considering the output of xgboost model 