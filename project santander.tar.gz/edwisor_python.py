#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import os 


# In[2]:


train = pd.read_csv("/home/akshay/Downloads/train.csv")


# In[3]:


test =pd.read_csv("/home/akshay/Downloads/test.csv")


# In[4]:


# dimensions 
train.shape , test.shape


# In[5]:


train.info()


# In[6]:


test.info()


# In[7]:


# look at first 5 records of train dataset
train.head()


# In[8]:


# look at first 5 records of test dataset
test.head()


# In[9]:


# look at statistical details of train dataset
train.describe()


# In[10]:


# look at statistical details of test dataset
test.describe()


# In[11]:


# Check the target variable distribution
train['target'].value_counts()


# In[12]:


import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().magic(u'matplotlib inline')


# In[13]:


sns.countplot(train['target'])


# In[14]:


# to check missing values 
test.isnull().any().any()
train.isnull().any().any()
# no missing values


# In[15]:


# Target variable from the Training Set
Target = train['target']
# Input dataset for Train and Test 
train_inp = train.drop(columns = ['target', 'ID_code'])
test_inp = test.drop(columns = ['ID_code'])


# In[16]:


featuress = list(train_inp.columns)


# In[17]:


featuress


# In[18]:


corr=test.corr()


# In[ ]:


# Imports for Modeling
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, roc_auc_score, auc, confusion_matrix, classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier


# In[20]:


# Split the Train Dataset into training and validation sets for model building. 
X_train, X_test, Y_train, Y_test = train_test_split(train_inp, Target,
                                                    test_size= 0.3, random_state=16)


# In[21]:


# check the split of train and validation
print('Train:',X_train.shape)
print('Test:',X_test.shape)


# In[22]:


# Create an object of Logistic Regression 
logistic = LogisticRegression()

# Fit the training data on this object
logistic.fit(X_train, Y_train)


# In[23]:


# Predict the Target for validation dataset 
logistic_pred = logistic.predict_proba(X_test)[:,1]


# In[24]:


logistic_pred


# In[25]:


def performance(Y_test, logistic_pred):
    logistic_pred_var = [0 if i < 0.5 else 1 for i in logistic_pred]
    print('Confusion Matrix:')
    print(confusion_matrix(Y_test, logistic_pred_var)) 
      
    #print(classification_report(Y_test, logistic_pred)) 

    fpr, tpr, thresholds = roc_curve(Y_test, logistic_pred, pos_label=1)
    print('AUC:')
    print(auc(fpr, tpr))


# In[23]:


performance(Y_test, logistic_pred)


# In[24]:


# Submission dataframe
logistic_pred_test = logistic.predict_proba(test_inp)[:,1]
submit = test[['ID_code']]
submit['target'] = logistic_pred_test

submit.head()


# In[25]:


# Create the Submission File using logistic regression model
submit.to_csv('logistic_reg.csv', index = False)


# In[29]:


# Create Decision Tree Classifier object 
tree_class = DecisionTreeClassifier(class_weight='balanced', random_state = 2019, 
                                  max_features = 0.7, min_samples_leaf = 80)

# Fit the object on training data
tree_class.fit(X_train, Y_train)


# In[30]:


# Predict for validation set and check the performance
tree_preds = tree_class.predict_proba(X_test)[:, 1]
performance(Y_test, tree_preds)


# In[31]:


# Submission dataframe
tree_pred_test = tree_class.predict_proba(test_inp)[:, 1]

submitTree = test[['ID_code']]
submitTree['target'] = tree_pred_test


# In[32]:


# Create the Submission File using decision tree model
submitTree.to_csv('Decision_Tree.csv', index = False)


# In[33]:


submitTree.head()


# In[36]:


# Extract feature importances
feature_importance_values = tree_class.feature_importances_
feature_importances = pd.DataFrame({'feature': features, 'importance': feature_importance_values})
feature_importances.sort_values(by='importance', ascending=False).head()


# In[35]:


plt.plot(tree_class.feature_importances_)


# In[41]:


# Create random Forest Object 
random_forest = RandomForestClassifier(n_estimators=100, random_state=2019, verbose=1,
                                      class_weight='balanced', max_features = 0.5, 
                                       min_samples_leaf = 100)

# Fit the object on training set 
random_forest.fit(X_train, Y_train)


# In[43]:


# Predict the validation set target and check the performance
forest_preds = random_forest.predict_proba(X_test)[:, 1]
performance(Y_test, forest_preds)


# In[ ]:


# Submission dataframe
forest_pred_test = random_forest.predict_proba(test_inp)[:, 1]

submitForest = test[['ID_code']]
submitForest['target'] = forest_pred_test


# In[ ]:


# Create the Submission File using random forest model
submitForest.to_csv('Random_Forest.csv', index = False)


# In[ ]:


submitForest.head()


# In[45]:


plt.plot(random_forest.feature_importances_)


# In[ ]:





# In[ ]:




